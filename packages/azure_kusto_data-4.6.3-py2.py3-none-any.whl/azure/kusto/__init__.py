# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License
"""Init file for azure namespace. https://github.com/Azure/azure-sdk-for-python/wiki/Azure-packaging"""
__path__ = __import__("pkgutil").extend_path(__path__, __name__)
